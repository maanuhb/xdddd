import React from "react";
const Controls = ({ children }) => {
  return <div>{children}</div>;
};
export default Controls;
