import React from "react";
const Layers = ({ children }) => {
  return <div>{children}</div>;
};
export default Layers;
