import "./App.css";

import Home from "./modules/home/home";

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
