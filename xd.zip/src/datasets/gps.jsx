const gps = {
    trips: {
      from: { t: 1688516019, y: 13.6754961014, x: -89.2938156128 },
      to: { t: 1688537672, y: 13.6758155823, x: -89.2937011719 },
      m: 1688537672,
      f: 0,
      state: 0,
      max_speed: 0,
      curr_speed: 0,
      avg_speed: 0,
      distance: 0,
      odometer: 68689176,
      course: 135,
      altitude: 948,
      pos_flags: 0,
    },
  };
export default gps;
